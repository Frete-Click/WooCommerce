=== FreteClick ===
Tags: FreteClick, Frete Click, Frete, Click, Carriers, Carrier, Transportadoras, Transportadora, Correios, Frete, Cálculo de Frete
Requires at least: 5.0
Contributors: freteclick
Stable tag: 1.0.3
Tested up to: 5.4.2
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Módulo para realização de frete com a Frete Click na plataforma Woocommerce.
== Description ==
Módulo para realização de frete com a Frete Click na plataforma Woocommerce.
== Installation ==
1. Carregue os arquivos do plug-in no diretório `/wp-content/plugins/freteclick` ou instale o plug-in diretamente na tela de plug-ins do WordPress.
2. Ative o plugin através da tela 'Plugins' no WordPress
3. Use a tela Configurações->FreteClick para configurar o plug-in
